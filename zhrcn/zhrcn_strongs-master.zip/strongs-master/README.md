Strong's Concordance
--------------------

The Strong's Concordance provides an index to the Bible. Each word in the original language is given an entry number, known as the **Strong's numbers**.

The main concordance lists the words that appear in the KJV Bible in alphabetical order, including 8674 Hebrew words used in the Old Testament and 5624 Greek words used in the New Testament.

License
-------

Please refer to different folders for the licenses.
