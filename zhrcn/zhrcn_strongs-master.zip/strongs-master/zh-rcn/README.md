The original content was provided by the [CBOL](https://bible.fhl.net/) project, under a [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License](https://creativecommons.org/licenses/by-nc-sa/4.0/).

The JSON files for words are created from `bible_gb_little.db`:
- The file can be downloaded from ftp://ftp.fhl.net/pub/FHL/COBS/data/. It was uploaded on 2017-06-29, 1:03:00 AM.
- The Hebrew words are taken from the `hsnum` and `txt` columns in the `hfhl` table.
- The Greek words are taken from the `gsnum` and `txt` columns in the `gfhl` table.

The JSON files for verses are created from `bible_gb_parsing.db`:
- The file can be downloaded from ftp://ftp.fhl.net/pub/FHL/COBS/data/. It was uploaded on 2017-06-29, 1:03:00 AM.
- The verses from Old Testament are taken from the `wid`, `sn` and `exp` columns in the `fhlwhparsing` table.
- The verses from New Testament are taken from the `wid`, `sn` and `exp` columns in the `lparsing` table.
